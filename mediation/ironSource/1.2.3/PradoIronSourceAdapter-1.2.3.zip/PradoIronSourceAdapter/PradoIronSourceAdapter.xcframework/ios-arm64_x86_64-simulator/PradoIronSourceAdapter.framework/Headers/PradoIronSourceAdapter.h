//
//  PradoIronSourceAdapter.h
//  PradoIronSourceAdapter
//
//  Created by Maria Yelfimova on 04/09/2024.
//  Copyright © 2024 Prado. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PradoIronSourceAdapter.
FOUNDATION_EXPORT double PradoIronSourceAdapterVersionNumber;

//! Project version string for PradoIronSourceAdapter.
FOUNDATION_EXPORT const unsigned char PradoIronSourceAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PradoIronSourceAdapter/PublicHeader.h>


