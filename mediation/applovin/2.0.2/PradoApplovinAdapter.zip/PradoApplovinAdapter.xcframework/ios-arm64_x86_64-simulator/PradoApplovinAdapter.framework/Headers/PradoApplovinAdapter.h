//
//  PradoApplovinAdapter.h
//  PradoApplovinAdapter
//
//  Created by Maria on 19/08/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for PradoApplovinAdapter.
FOUNDATION_EXPORT double PradoApplovinAdapterVersionNumber;

//! Project version string for PradoApplovinAdapter.
FOUNDATION_EXPORT const unsigned char PradoApplovinAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PradoApplovinAdapter/PublicHeader.h>


