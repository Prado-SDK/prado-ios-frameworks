//
//  PradoAdmobAdapter.h
//  PradoAdmobAdapter
//
//  Created by Maria on 26/08/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for PradoAdmobAdapter.
FOUNDATION_EXPORT double PradoAdmobAdapterVersionNumber;

//! Project version string for PradoAdmobAdapter.
FOUNDATION_EXPORT const unsigned char PradoAdmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PradoAdmobAdapter/PublicHeader.h>


