//
//  PradoSDK.h
//  PradoSDK
//
//  Created by Maria Yelfimova on 01/05/2024.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for PradoSDK.
FOUNDATION_EXPORT double PradoSDKVersionNumber;

//! Project version string for PradoSDK.
FOUNDATION_EXPORT const unsigned char PradoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PradoSDK/PublicHeader.h>

#import <PradoSDK/PradoSDK-Bridging-Header.h>
